package com.senter.demo.uhf.common;

public class ExceptionForToast extends Exception {
    private static final long serialVersionUID = 4753428475775989796L;

    public ExceptionForToast(String msg) {
        super(msg);
    }

}
